package edu.ucsf.rbvi.myapp2.internal.tasks;

import java.util.HashMap;
import java.util.Map;

import org.cytoscape.command.AvailableCommands;
import org.cytoscape.command.CommandExecutorTaskFactory;
import org.cytoscape.service.util.CyServiceRegistrar;
import org.cytoscape.work.AbstractTask;
import org.cytoscape.work.SynchronousTaskManager;
import org.cytoscape.work.TaskIterator;
import org.cytoscape.work.TaskMonitor;

public class MyApp2Task extends AbstractTask {
	final CyServiceRegistrar registrar;
	public MyApp2Task(final CyServiceRegistrar registrar) {
		super();
		this.registrar = registrar;
	}

	public void run(TaskMonitor monitor) { 

		// Get all of our services
		SynchronousTaskManager stm = registrar.getService(SynchronousTaskManager.class);
		AvailableCommands available = registrar.getService(AvailableCommands.class);
		CommandExecutorTaskFactory taskFactory = registrar.getService(CommandExecutorTaskFactory.class);
		
		// Set our tunables
		Map<String, Object> args = new HashMap<>();
		args.put("nodeShape", "Diamond");
		args.put("lowerColor", "cyan");
		args.put("upperColor", "yellow");

		// Get the task iterator
		TaskIterator ti = taskFactory.createTaskIterator("MyApp", "HelloWorld", args, null);

		// Do it!
		stm.execute(ti);

	}
}

package your.org.myapp.internal.tasks;


import org.cytoscape.model.CyEdge;
import org.cytoscape.model.CyNetwork;
import org.cytoscape.model.CyNetworkFactory;
import org.cytoscape.model.CyNetworkManager;
import org.cytoscape.model.CyNode;
import org.cytoscape.work.AbstractTask;
import org.cytoscape.work.ProvidesTitle;
import org.cytoscape.work.TaskFactory;
import org.cytoscape.work.TaskMonitor;

public class MyAppTask extends AbstractTask {
	final CyNetworkFactory netFactory;
	final CyNetworkManager netManager;

	public MyAppTask(CyNetworkManager netManager, CyNetworkFactory networkFactory) {
		super();
		this.netFactory = networkFactory;
		this.netManager = netManager;
	}

	public void run(TaskMonitor monitor) {
		CyNetwork myNetwork = netFactory.createNetwork();
		CyNode node1 = myNetwork.addNode();
		CyNode node2 = myNetwork.addNode();
		CyEdge edge1 = myNetwork.addEdge(node1, node2, false);

		// The network needs a name or the Network Manager won't
		// add it.
		myNetwork.getRow(myNetwork).set(CyNetwork.NAME, "My Network");
		netManager.addNetwork(myNetwork);

		monitor.setStatusMessage("Added network");
	}

	@ProvidesTitle
	public String getTitle() { return "MyApp Task"; }

}

package your.org.myapp.internal.tasks;

import org.cytoscape.model.CyNetworkFactory;
import org.cytoscape.model.CyNetworkManager;
import org.cytoscape.work.AbstractTaskFactory;
import org.cytoscape.work.TaskFactory;
import org.cytoscape.work.TaskIterator;

public class MyAppTaskFactory extends AbstractTaskFactory {
	final CyNetworkFactory netFactory;
	final CyNetworkManager netManager;

	public MyAppTaskFactory(CyNetworkManager manager, CyNetworkFactory networkFactory) {
		super();
		netFactory = networkFactory;
		netManager = manager;
	}

	public TaskIterator createTaskIterator () {
		return new TaskIterator(new MyAppTask(netManager, netFactory)); 
	}

	public boolean isReady() { return true; }
}
